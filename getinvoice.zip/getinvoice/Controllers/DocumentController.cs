﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using getinvoice.Common;
using getinvoice.DAL.Context;
using getinvoice.DAL.TableModel;
using getinvoice.Models;
using getinvoice.Models.InvoiceFormModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace getinvoice.Controllers
{
    [Route("Document")]
    [ApiController]
    public class DocumentController : ControllerBase
    {
        private readonly Getinvoicecontext _dbcontext;
        private GenerateInvoiceService _invoiceService;
        public DocumentController(Getinvoicecontext dbcontext, GenerateInvoiceService invoiceService)
        {
            _dbcontext = dbcontext;
            _invoiceService = invoiceService;

        }
        [Route("GetInvoiceForm")]
        [HttpGet]
        [Authorize(Policy = Policies.User)]
        public ReturnModel GetinvoiceForm(int Job_Id)
        {

            ReturnModel returnModel = new ReturnModel();
            var data = _dbcontext.InvoiceForm.Select(e => new
            {
                JobId = e.Job_Id,
                CustomerCompanyName = e.Customer_CompanyName,


            }).FirstOrDefault(x => x.JobId == Job_Id);


            if (data != null)
            {
                returnModel.Message = "Data get Successfully  ";
                returnModel.ResponseData = data;
                returnModel.StatusCode = HttpStatusCode.OK;

            }

            else
            {
                returnModel.Message = " data  not found";
                returnModel.ResponseData = data;
                returnModel.StatusCode = HttpStatusCode.NotFound;

            }

            return returnModel;


        }

        [Route("AddInvoice")]
        [HttpPost]
        public ReturnModel AddInvoice(PostInvoiceForm AddInvoice)
        {
            ReturnModel returnModel = new ReturnModel();
            var A_Exist = _dbcontext.InvoiceForm.FirstOrDefault(u => u.Job_Id == AddInvoice.Job_Id);
            if (A_Exist != null)
            {
                returnModel.StatusCode = HttpStatusCode.Continue;
                returnModel.Message = "Invoice Already Exist, continue forward";
            }
            else
            {
                InvoiceFormTable newform = new InvoiceFormTable()
                {
                    Customer_CompanyName = AddInvoice.Customer_CompanyName,
                    Company_Address = AddInvoice.Company_Address,

                    Currency = AddInvoice.Currency,
                    Date_issued = AddInvoice.Date_issued,
                    Date_Due = AddInvoice.Date_Due,
                    Email = AddInvoice.Email,
                    Job_description = AddInvoice.Job_description,
                    Total_Payment = AddInvoice.Total_Payment,

                    CreatedDateTime = DateTime.UtcNow,
                    customer_Id = AddInvoice.customer_Id,
                    DeletedDateTime = null,
                    IsActive = true,
                    IsDeleted = false,
                    IsUpdated = false,
                    UpdateDateTime = null
                };
                _dbcontext.InvoiceForm.Add(newform);
                var IsDataSave = _dbcontext.SaveChanges();
                if (IsDataSave > 0)
                {
                    returnModel.StatusCode = HttpStatusCode.OK;
                    returnModel.Message = "New Invoice Add Successfully ";
                }
                else
                {
                    returnModel.StatusCode = HttpStatusCode.BadRequest;
                    returnModel.Message = "Invoice couldn't be added, Please try after some time";
                }
            }
            return returnModel;

        }

        [Route("updateForm")]
        [HttpPut]
        public ReturnModel updateForm(Updateform update)
        {
            ReturnModel returnModel = new ReturnModel();
            try
            {
                var user = _dbcontext.InvoiceForm.Where(x => x.Job_Id == update.Job_Id).FirstOrDefault();
                if (user != null)
                {
                    user.contact = update.contact;
                    user.Currency = update.Currency;
                    user.Date_issued = update.Date_issued;
                    user.Date_Due = update.Date_Due;
                    user.Total_Payment = update.Total_Payment;
                    user.Job_description = update.Job_description;
                    user.Email = update.Email;


                    user.IsUpdated = true;
                    user.UpdateDateTime = DateTime.UtcNow;

                    _dbcontext.InvoiceForm.Update(user);
                    var Isupdated = _dbcontext.SaveChanges();
                    if (Isupdated > 0)
                    {
                        returnModel.StatusCode = HttpStatusCode.OK;
                        returnModel.Message = "Successfully updated ";
                        returnModel.ResponseData = user;
                    }
                    else
                    {
                        returnModel.StatusCode = HttpStatusCode.BadRequest;
                        returnModel.Message = "can't update ";
                    }
                }
                else
                {
                    returnModel.StatusCode = HttpStatusCode.NotFound;
                    returnModel.Message = " not found";
                }

            }
            catch (Exception ex)
            {
                returnModel.StatusCode = HttpStatusCode.InternalServerError;
                returnModel.Message = ex.Message.ToString();
            }
            return returnModel;
        }
        [Route("GetInvoiceData")]
        [HttpGet]
        public async Task<ReturnModel> GetInvoiceData(InvoiceServiceModel serviceModel)
        {
            ReturnModel returnModel = new ReturnModel();
            await _invoiceService.databind(serviceModel);
            return returnModel;
        }

    }
}