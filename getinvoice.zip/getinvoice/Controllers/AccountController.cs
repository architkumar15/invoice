﻿using Microsoft.AspNetCore.Mvc;
using getinvoice.DAL.Context;
using getinvoice.DAL.TableModel;
using getinvoice.Models;
using getinvoice.Models.RegisterModel;
using getinvoice.Models.DemoModel;
using getinvoice.Models.ContactUsModel;
using getinvoice.Common;

using System;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace getinvoice.Controllers
{
    [Route("api/account")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly Getinvoicecontext _dbContext;
        private readonly OtpServices _oTPMANAGER;
        private readonly JwtService _jwtservice;
        public AccountController(Getinvoicecontext dbContext, OtpServices oTPMANAGER, JwtService jwtservice)
        {
            _dbContext = dbContext;
            _oTPMANAGER = oTPMANAGER;
            _jwtservice = jwtservice;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="NewAccount"></param>
        /// <returns></returns>
        [Route("RegisterNewUser")]
        [HttpPost]
        [AllowAnonymous]
        public ReturnModel RegisterNewUser([FromBody] NewRegister NewAccount)
        {
            ReturnModel returnModel = new ReturnModel();

            try
            {

                var A_Exist = _dbContext.Register.FirstOrDefault(u => u.Email == NewAccount.Email);
                if (A_Exist != null)
                {
                    returnModel.StatusCode = HttpStatusCode.Continue;
                    returnModel.Message = "User Already Exist, continue forword";
                }
                else
                {
                    RegisterTable newtable = new RegisterTable()
                    {
                        Full_name = NewAccount.Full_name,
                        Email = NewAccount.Email,
                        Company_name = NewAccount.Company_name,
                        Contact = NewAccount.Contact,
                        Register_password = NewAccount.Register_password,
                        IsActive = true,
                        IsDeleted = false,
                        IsUpdated = false,
                        CreatedDateTime = DateTime.UtcNow,
                        DeletedDateTime = null,
                        UpdateDateTime = null,
                        OTP_Generatetime = null,
                        RestPasswordTime = null,
                        ForgetPasswordTime = null,
                        OTP = null
                    };

                    _dbContext.Register.Add(newtable);

                    var IsDataSave = _dbContext.SaveChanges();
                    if (IsDataSave == 1)
                    {
                        returnModel.StatusCode = HttpStatusCode.OK;
                        returnModel.Message = "New Account Add Successfully ";
                    }
                    else
                    {
                        returnModel.StatusCode = HttpStatusCode.BadRequest;
                        returnModel.Message = "Account couldn't be added, Please try after some time";
                    }
                }

            }
            catch (Exception ex)
            {
                ExceptionLoger.LogInfo(ex.Message);
                returnModel.Message = ex.Message;
            }
            return returnModel;
        }

        [Route("Login")]
        [HttpPost]
        [AllowAnonymous]
        public ReturnModel Login([FromBody] SignIn log)
        {
            ReturnModel returnModel = new ReturnModel();
            try
            {
                var userlist = _dbContext.Register.FirstOrDefault(x => x.Email.ToLower() == log.Email.ToLower() && x.Register_password == log.Password && x.IsActive && !x.IsDeleted);
                if (userlist != null)
                {
                    LoginTable entry = new LoginTable
                    {
                        CreatedDateTime = DateTime.UtcNow,
                        Email = log.Email,
                        DeletedDateTime = null,
                        IsActive = true,
                        IsDeleted = false,
                        IsUpdated = false,
                        UpdateDateTime = null,
                        OTP_Generatetime = null,
                        RestPasswordTime = null,
                        ForgetPasswordTime = null
                        
                    };
                    _dbContext.Login.Add(entry);
                    _dbContext.SaveChanges();
                    User user = new User
                    {
                        UserContact = userlist.Contact,
                        UserName = userlist.Full_name,
                        UserEmail = userlist.Email,
                        RegisterId = userlist.Register_Id.ToString(),
                        Company_Name = userlist.Company_name,
                        UserRole = "User"

                    };
                   var tokenData = _jwtservice.CreateToken(user);
                    returnModel.StatusCode = HttpStatusCode.OK;
                    returnModel.ResponseData = new { userlist,tokenData};
                    returnModel.Message = "User can login successfully";
                }
                else
                {
                    returnModel.StatusCode = HttpStatusCode.NotFound;
                    returnModel.Message = "user not found";
                }
            }

            catch (Exception ex)
            {
                ExceptionLoger.LogInfo(ex.Message);
                returnModel.Message = ex.Message;

            }
            return returnModel;
        }
        [Route("GetUser")]
        [HttpGet]
        [Authorize(Policy = Policies.User)]
        public ReturnModel Get(string email)
        {
            ReturnModel returntModel = new ReturnModel();

            try
            {
                //var data = _dbContext.Register.Select(t => new
                //{
                //    FullName = t.Full_name,
                //    Email = t.Email,
                //    Register_Id = t.Register_Id,
                //    Company_name = t.Company_name,
                //    Contact = t.Contact
                ////})/*.FirstOrDefault(x => x.Email.ToLower() == email.ToLower());*/
                //    //string token = _JWTHandler.GenerateJWTToken(email ?);
               

                //if (data != null)
                //{
                //    returnModel.Message = "Data Sent Succesfull";
                //    returnModel.ResponseData = data;
                //    returnModel.StatusCode = HttpStatusCode.OK;
                //}
                //else
                //{
                //    returnModel.Message = "No data found";
                //    returnModel.ResponseData = data;
                //    returnModel.StatusCode = HttpStatusCode.NotFound;

                //}

            }
            catch (Exception ex)
            {
                ExceptionLoger.LogInfo(ex.Message);
                

            }

            return returntModel;
        }

        [Route("Updatepassword")]
        [HttpPost]
        public ReturnModel Updatepassword(UpdateUser updateUser)
        {
            ReturnModel returnModel = new ReturnModel();
            try
            {
                var user = _dbContext.Register.FirstOrDefault(a => a.Contact == updateUser.contact);
                if (user != null)
                {
                    user.Register_password = updateUser.password;
                    user.IsUpdated = true;
                    user.RestPasswordTime = DateTime.UtcNow;

                    _dbContext.Register.Update(user);
                    var Isupdated = _dbContext.SaveChanges();
                    if (Isupdated > 0)
                    {
                        returnModel.StatusCode = HttpStatusCode.OK;
                        returnModel.Message = "Successfully updated user info";
                        returnModel.ResponseData = user;
                    }
                    else
                    {
                        returnModel.StatusCode = HttpStatusCode.BadRequest;
                        returnModel.Message = "can't update user info";
                    }
                }
                else
                {
                    returnModel.StatusCode = HttpStatusCode.NotFound;
                    returnModel.Message = "user not found";
                }

            }
            catch (Exception ex)
            {
                returnModel.StatusCode = HttpStatusCode.InternalServerError;
                returnModel.Message = ex.Message.ToString();
            }
            return returnModel;
        }
        [Route("OTPsendtocontact")]
        [HttpGet]
        [AllowAnonymous]
        public ReturnModel OTPsendtocontact(string contact)
        {
            ReturnModel returnModel = new ReturnModel();
            var user = _dbContext.Register.FirstOrDefault(a => a.Contact == contact);
            if (user != null)
            {
                string OTP = _oTPMANAGER.GenerateOtp();
                bool isSent = _oTPMANAGER.sendotp(user.Contact, OTP);
                if (isSent)
                {
                    user.OTP = OTP;
                    user.OTP_Generatetime = DateTime.UtcNow;
                    _dbContext.Register.Update(user);
                    int ff = _dbContext.SaveChanges();
                    if (ff > 0)
                    {
                        returnModel.Message = "OTP sent successfully";
                        returnModel.StatusCode = HttpStatusCode.OK;
                    }
                    else
                    {
                        returnModel.Message = "your request can't be process right now";
                        returnModel.StatusCode = HttpStatusCode.BadRequest;
                    }
                }
                else
                {
                    returnModel.Message = "OTP Can't be sent right now";
                    returnModel.StatusCode = HttpStatusCode.BadRequest;
                }
            }
            else
            {
                returnModel.Message = "Contact dosen't exist";
                returnModel.StatusCode = HttpStatusCode.NotFound;
            }
            return returnModel;
        }
        [Route("OTPverification")]
        [HttpGet]
        [AllowAnonymous]
        public ReturnModel OTPverification(string otp, string contact)
        {
            ReturnModel returnModel = new ReturnModel();
            var user = _dbContext.Register.FirstOrDefault(a => a.OTP == otp && a.Contact == contact);
            if (user != null)
            {
                var diff = DateTime.UtcNow - user.OTP_Generatetime;
                if (user.OTP == otp && diff.Value.TotalMinutes < 10)
                {
                    returnModel.Message = "You're verified now, please proceed for ResetPassword";
                    returnModel.StatusCode = HttpStatusCode.OK;


                }
                else
                {
                    returnModel.Message = "Either otp is incorrect or expired";
                    returnModel.StatusCode = HttpStatusCode.BadRequest;
                }
            }
            else
            {
                returnModel.Message = "OTP is invalid or user doesn't exist";
                returnModel.StatusCode = HttpStatusCode.NotFound;
            }

            return returnModel;
        }


        [Route("NewDemoEntry")]
        [HttpPost]
        [Authorize(Policy = Policies.User)]
        public ReturnModel NewDemoEntry(NewDemo NewQuery)
        {
            ReturnModel returnModel = new ReturnModel();
            var A_Exist = _dbContext.Demo.FirstOrDefault(u => u.Email == NewQuery.Email);
            if (A_Exist != null)
            {
                returnModel.StatusCode = HttpStatusCode.Continue;
                returnModel.Message = "Demo Already Exist, continue forword";
            }
            else
            {
                DemoTable newtable = new DemoTable()
                {
                    Full_name = NewQuery.Full_name,
                    Email = NewQuery.Email,
                    Company_name = NewQuery.Company_name,
                    Phone_No = NewQuery.Phone_No,
                    IsActive = true,
                    IsDeleted = false,
                    IsUpdated = false,
                    CreatedDateTime = DateTime.UtcNow,
                    DeletedDateTime = null,
                    UpdateDateTime = null

                };
                _dbContext.Demo.Add(newtable);
                var IsDataSave = _dbContext.SaveChanges();
                if (IsDataSave == 1)
                {
                    returnModel.StatusCode = HttpStatusCode.OK;
                    returnModel.Message = "New Demo Add Successfully ";
                }
                else
                {
                    returnModel.StatusCode = HttpStatusCode.BadRequest;
                    returnModel.Message = "Demo couldn't be added, Please try after some time";
                }
            }
            return returnModel;

        }
        [Route("NewQueryEntry")]
        [HttpPost]
        [Authorize(Policy = Policies.User)]
        public ReturnModel NewQueryEntry([FromBody] NewQuery NewInfoQuery)
        {
            ReturnModel returnModel = new ReturnModel();
            var A_Exist = _dbContext.ContactUs.FirstOrDefault(u => u.Email == NewInfoQuery.Email);
            if (A_Exist != null)
            {
                returnModel.StatusCode = HttpStatusCode.Continue;
                returnModel.Message = "Query Already Exist, continue forword";
            }
            else
            {
                ContactusTable newtable = new ContactusTable()
                {
                    Full_name = NewInfoQuery.Full_name,
                    Last_name = NewInfoQuery.Last_name,
                    Email = NewInfoQuery.Email,
                    Query_message = NewInfoQuery.Query_message,
                    IsActive = true,
                    IsDeleted = false,
                    IsUpdated = false,
                    CreatedDateTime = DateTime.UtcNow,
                    DeletedDateTime = null,
                    UpdateDateTime = null

                };
                _dbContext.ContactUs.Add(newtable);
                var IsDataSave = _dbContext.SaveChanges();
                if (IsDataSave == 1)
                {
                    returnModel.StatusCode = HttpStatusCode.OK;
                    returnModel.Message = "New Query Add Successfully ";
                }
                else
                {
                    returnModel.StatusCode = HttpStatusCode.BadRequest;
                    returnModel.Message = "Query couldn't be added, Please try after some time";
                }
            }
            return returnModel;

        }


    }
}
