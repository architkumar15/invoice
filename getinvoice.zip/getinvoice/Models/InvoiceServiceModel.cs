﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace getinvoice.Models
{
    public class InvoiceServiceModel
    {
        public int Id { get; set; }
        public string Job_Description { get;set; }
        public DateTime Issued_Date { get; set; }
        public DateTime Due_Date { get; set; }
        public string Address { get; set; }
        public string Country { get; set; }
        public string Email { get; set; }
        public string Contact_Number { get; set; }
        public string Resource_Name { get; set; }
        public string Customer_Name { get; set; }
        public int Customer_Id { get; set; }
        public string Company_Name { get; set; }
        public string ProjectName { get; set; }
        public string Task { get; set; }
        public string GST { get; set; }
        public string Amount { get; set; }
        public string Due_Amount { get; set; }
        public string Invoice_Cycle { get; set; }












    }
}
