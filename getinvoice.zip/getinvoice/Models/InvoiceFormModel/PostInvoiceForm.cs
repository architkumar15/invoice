﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace getinvoice.Models.InvoiceFormModel
{
    public class PostInvoiceForm
    {
        public int Job_Id { get; set; }
        public string Job_description { get; set; }
        public string Customer_CompanyName { get; set; }
        public String Company_Address { get; set; }
        public string contact { get; set; }
        public String Email { get; set; }
        public string Total_Payment { get; set; }
        public string Currency { get; set; }
        public DateTime Date_issued { get; set; }
        public DateTime Date_Due { get; set; }
        public int customer_Id { get; set; }
    }
}
