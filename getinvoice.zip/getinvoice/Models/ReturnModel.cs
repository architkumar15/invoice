﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net;


namespace getinvoice.Models
{
    public class ReturnModel
    {
       
            public string Message { get; set; }
            public dynamic ResponseData { get; set; }
            public HttpStatusCode StatusCode { get; set; }
        
    }
}
