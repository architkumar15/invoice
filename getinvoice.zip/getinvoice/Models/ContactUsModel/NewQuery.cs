﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace getinvoice.Models.ContactUsModel
{
    public class NewQuery
    {
        public string Full_name { get; set; }
        public string Last_name { get; set; }
        public string Email { get; set; }
        public string Query_message { get; set; }
    }
}
