﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace getinvoice.Models.DemoModel
{
    public class NewDemo
    {
        public string Full_name { get; set; }
        public string Email { get; set; }
        public string Company_name { get; set; }
        [Required]
        [Phone]
        [MinLength(10), MaxLength(10)]
        public string Phone_No { get; set; }
    }
}
