﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace getinvoice.Models.RegisterModel
{
    public class NewRegister
    {
        [Required]
        public string Full_name { get; set; }
        [Required]

        public string Email { get; set; }
        [Required]

        public string Company_name { get; set; }
        [Required]

        public string Register_password { get; set; }
        [Required]
        [Phone]
        [MinLength(10),MaxLength(10)]
        public string Contact { get; set; }


    }
}
