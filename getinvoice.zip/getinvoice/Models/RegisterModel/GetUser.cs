﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace getinvoice.Models.RegisterModel
{
    public class GetUser
    {
     
        [Required]
        public string Email { get; set; }
      

    }
}
