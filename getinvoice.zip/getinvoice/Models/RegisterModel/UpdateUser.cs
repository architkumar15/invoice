﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace getinvoice.Models.RegisterModel
{
    public class UpdateUser
    {
        public string password { get; set; }

        [Required]
        [Phone]
        [MinLength(10), MaxLength(10)]
        public string contact { get; set; }

    }
}
