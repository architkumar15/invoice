﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace getinvoice.DAL.TableModel
{
    public class BaseClass
    {
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsUpdated { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public DateTime? DeletedDateTime { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        //public DateTime? OTP_Generatetime { get; set; }
        //public DateTime? RestPasswordTime { get; set; }
        //public DateTime? ForgetPasswordTime { get; set; }

    }
}
