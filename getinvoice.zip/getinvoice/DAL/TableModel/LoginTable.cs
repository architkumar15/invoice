﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace getinvoice.DAL.TableModel
{
    public class LoginTable:BaseClass
    {
        [Key]
        public string Email { get; set; }
        public DateTime? OTP_Generatetime { get; set; }
        public DateTime? RestPasswordTime { get; set; }
        public DateTime? ForgetPasswordTime { get; set; }
    }
}
