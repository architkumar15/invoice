﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace getinvoice.DAL.TableModel
{
    public class RegisterTable:BaseClass
    {
        [Key]
        public int Register_Id { get; set; }
        public string Full_name { get; set; }
        public string Email { get; set; }
        public string Company_name { get; set; }
        public string Register_password { get; set; }
        public string Contact { get; set; }

        public string OTP { get; set; }
        public DateTime? OTP_Generatetime { get; set; }
        public DateTime? RestPasswordTime { get; set; }
        public DateTime? ForgetPasswordTime { get; set; }





    }
}
