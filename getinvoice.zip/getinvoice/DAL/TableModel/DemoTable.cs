﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace getinvoice.DAL.TableModel
{
    public class DemoTable:BaseClass
    {
        [Key]
        public int Demo_Id { get; set; }
        public string Full_name { get; set; }
        public string Email { get; set; }
        public string Company_name { get; set; }
        public string Phone_No { get; set; }
    }
}

