﻿using System;
using Microsoft.EntityFrameworkCore;
using getinvoice.DAL.Context;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using getinvoice.DAL.TableModel;

namespace getinvoice.DAL.Context
{
    public class Getinvoicecontext:DbContext
    {
        public Getinvoicecontext(DbContextOptions<Getinvoicecontext> Option) : base(Option)
        {

        }
        public DbSet<RegisterTable> Register { get; set; }
        public DbSet<DemoTable> Demo { get; set; }
        public DbSet<ContactusTable> ContactUs { get; set; }
        public DbSet<LoginTable> Login { get; set; }
        public DbSet<InvoiceFormTable> InvoiceForm { get; set; }


    }
}

