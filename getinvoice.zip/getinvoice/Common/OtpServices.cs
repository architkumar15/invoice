﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace getinvoice.Common
{
    public class OtpServices
    {
        private readonly IConfiguration _config;
        public OtpServices(IConfiguration configuration)
        {
            _config = configuration;
        }
        public string GenerateOtp()
        {
            string otp = "";
            Random random = new Random();
            otp = random.Next(1000, 9999).ToString();
            return otp;
        }

        public bool sendotp(string phoneNo, string otp)
        {
            try
            {

                phoneNo = Constant.CountryCode + phoneNo;
                string accountSid = _config.GetSection(Constant.AccountSid).Value;
                string authToken = _config.GetSection(Constant.AuthToken).Value;


                TwilioClient.Init(accountSid, authToken);

                var message = MessageResource.Create(
                    body: Constant.OtpMessage + otp,
                    from: new Twilio.Types.PhoneNumber(_config.GetSection(Constant.MyNumber).Value),
                    to: new Twilio.Types.PhoneNumber(phoneNo)
                );

                if (!message.ErrorCode.HasValue)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {

                return false;

            }

        }

    }
}
