﻿using getinvoice.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace getinvoice.Common
{
    public class JwtService
    {
        private readonly IConfiguration _config;

        public JwtService(IConfiguration config)
        {
            _config = config;

        }
        public TokenDTO CreateToken(User user)
        {

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:SecretKey"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var claims = new[]            {
new Claim(JwtRegisteredClaimNames.Sub, user.UserName),
new Claim("userId", user.RegisterId),
new Claim("email", user.UserEmail),
new Claim("role",user.UserRole),
new Claim("Ucontact",user.UserContact),
new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
};
            DateTime expiryTime = DateTime.Now.AddDays(7);
            var jwtToken = new JwtSecurityToken(
            issuer: _config["Jwt:Issuer"],
            audience: _config["Jwt:Audience"],
            claims: claims,
            expires: expiryTime,
            signingCredentials: credentials
            );
            JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
            return new TokenDTO()
            {
                AccessToken = tokenHandler.WriteToken(jwtToken),
                ExpiresIn = expiryTime,
                TokenType = "Bearer"
            };
        }
    }
    public class TokenDTO
    {
        public string AccessToken { get; set; }
        public DateTime ExpiresIn { get; set; }
        public string TokenType { get; set; }
    }
}
