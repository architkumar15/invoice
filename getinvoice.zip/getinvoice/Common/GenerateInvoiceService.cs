﻿using getinvoice.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace getinvoice.Common
{
    public class GenerateInvoiceService
    {

        private readonly IConfiguration _config;
        public GenerateInvoiceService(IConfiguration configuration)
        {
            _config = configuration;
        }
        public async Task<bool> databind(InvoiceServiceModel serviceModel)
        {
            try
            {


            var todaydate = DateTime.UtcNow.Date.ToString();
            string emailtemplatepath = System.IO.Path.Combine(Environment.CurrentDirectory + "//wwwroot//template//htmlpage.html");
            string emailbody = System.IO.File.ReadAllText(emailtemplatepath);
            emailbody = emailbody.Replace("{{Job_Description}}", serviceModel.Job_Description);
            emailbody = emailbody.Replace("{{Issued_Date}}", serviceModel.Issued_Date.ToString() );
            emailbody = emailbody.Replace("{{Due_Date}}",serviceModel.Due_Date.ToString() );
            emailbody = emailbody.Replace("{{Invoice_Cycle}}",serviceModel.Invoice_Cycle.ToString());
            emailbody = emailbody.Replace("{{Address}}", serviceModel.Address);
            emailbody = emailbody.Replace("{{Country}}", serviceModel.Country);
            emailbody = emailbody.Replace("{{Email}}", serviceModel.Email);
            emailbody = emailbody.Replace("{{Contact_Number}}",serviceModel.Contact_Number);
            emailbody = emailbody.Replace("{{Resource_Name}}", serviceModel.Resource_Name);
            emailbody = emailbody.Replace("{{Customer_Name}}", serviceModel.Customer_Name);
            emailbody = emailbody.Replace("{{ProjectName}}", serviceModel.ProjectName);
            emailbody = emailbody.Replace("{{Task}}", serviceModel.Task);
            emailbody = emailbody.Replace("{{GST}}", serviceModel.GST);
            emailbody = emailbody.Replace("{{Amount}}",serviceModel.Amount);
                emailbody = emailbody.Replace("{{Due_Amount}}",serviceModel.Due_Amount);
                emailbody = emailbody.Replace("{{Customer_Id}}",serviceModel.Customer_Id.ToString());

            emailbody = emailbody.Replace("{{Company_Name}}", serviceModel.Company_Name);
            string path = Directory.GetCurrentDirectory() + "\\wwwroot\\SavedFiles\\";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string newPath = path + "INVOICE-VV" + serviceModel + ".html";
            //if (!System.IO.File.Exists(newPath))
            //{
            //    System.IO.File.Create(newPath);
            //System.IO.File.
            //}
            await System.IO.File.AppendAllTextAsync(newPath, emailbody);
            //using (StreamWriter sw =)
            //{
            //    sw.WriteLine(emailbody);
            //    sw.Flush();
            //    sw.Close();
            //}

            return true;

            }
            catch (Exception ex)
            {
                ExceptionLoger.LogInfo(ex.Message);
                return false;
            }

        }
        
        

    }
}
