﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace getinvoice.Common
{
    public static class ExceptionLoger
       
    {
       
        public static void LogInfo(string message)
        {
            var line = Environment.NewLine;
            try
            {
                string filepath = @"wwwroot/ErrorLog/";  //Text File Path

                if (!Directory.Exists(filepath))
                {
                    Directory.CreateDirectory(filepath);
                }
                filepath = filepath + "ErrLog_" + DateTime.Today.ToString("dd-MM-yyyy") + ".txt";   //Text File Name
                if (!File.Exists(filepath))
                {
                    File.Create(filepath).Dispose();
                }

                using (StreamWriter sw = File.AppendText(filepath))
                {
                    sw.WriteLine("-----------Information Log Details on " + " " + DateTime.Now.ToString() + "-----------------");
                    sw.WriteLine(message);
                    sw.WriteLine("--------------------------------*End*------------------------------------------");
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception e)
            {
                e.ToString();
            }
        }
    }
}
