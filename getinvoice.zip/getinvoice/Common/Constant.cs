﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace getinvoice.Common
{
    public class Constant
    {
        #region OtpService
        /// <summary>
        /// These constant are being used in otp service 
        /// </summary>
        public const string AccountSid = "Twilio:AccountSID";
        public const string AuthToken = "Twilio:AuthToken";
        public const string MyNumber = "Twilio:MyNumber";
        public const string CountryCode = "+91";
        public const string OtpMessage = "Your OTP is ";
        
        #endregion


    }
   
}
